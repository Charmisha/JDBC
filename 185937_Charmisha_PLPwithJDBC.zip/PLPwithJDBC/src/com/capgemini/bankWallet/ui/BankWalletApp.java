package com.capgemini.bankWallet.ui;

import java.util.Scanner;

import com.capgemini.bankWallet.exception.InsufficientBalanceException;
import com.capgemini.bankWallet.service.BankWalletService;
import com.capgemini.bankWallet.service.BankWalletServiceImpl;

public class BankWalletApp {
	public static void main(String[] args) 
	{
		BankWalletService bservice=new BankWalletServiceImpl();
		String acNo,name,mobileNo,aadharNo,pin;
		Scanner sc=new Scanner(System.in);
		long accountBalance;
		String proceed;
		int choice;
		do
		{
		  System.out.println("Enter your choice\n1.Create Account\n2.Show Balance\n3.Deposit\n4.Withdraw\n5.Fund Transfer");
		  choice=sc.nextInt();
		  switch(choice)
		  {
		   case 1:System.out.println("Enter Account Number");
		          acNo=sc.next();
		          if(bservice.validateAccountNumber(acNo))
		          {
		           System.out.println("Enter Name");
		           name=sc.next();
		           if(bservice.validateName(name))
		           {
		            System.out.println("Enter Mobile Number");
		            mobileNo=sc.next();
		            if(bservice.validateMobileNumber(mobileNo))
			        {
		             System.out.println("Enter Aadhar Number");
		             aadharNo=sc.next();
		             if(bservice.validateAadharNumber(aadharNo))
		             {
		              System.out.println("Set pin");
		              pin=sc.next();
		              if(bservice.validatePin(pin))
		              {
		               boolean created=bservice.createAccount(acNo, name, mobileNo, aadharNo, pin);
		               if(created)
		        	    System.out.println("Account created successfully");
		               else
		        	    System.out.println("Account creation failed.....Try Again...");
		              }
		             }
		            }
		           }
		          }
			      break;
		   case 2:System.out.println("Enter Account Number");
	              acNo=sc.next();
	              if(bservice.validateAccountNumber(acNo))
	              {
	               System.out.println("Enter pin");
	               pin=sc.next();
	               if(bservice.validatePin(pin))
	               {   
	                accountBalance=bservice.showBalance(acNo, pin);
	                if(accountBalance>=0)
	            	  System.out.println("Account Balance :"+accountBalance);
	                else
	            	   System.out.println("Please Try Again.....");
	               }
	              }
			      break;
		   case 3:System.out.println("Enter Account Number");
		          acNo=sc.next();
		          if(bservice.validateAccountNumber(acNo))
		          {
		           System.out.println("Enter Amount to Deposit");
		           long damount=sc.nextLong();
		           accountBalance=bservice.deposit(acNo, damount);
		           if(accountBalance>=0)
		           {
	                System.out.println("Amount Deposited Successfully");  
		            System.out.println("Account Balance:"+accountBalance);
		           }
		           else
		           {
	            	 System.out.println("Given Account Number Does Not Exist");
	            	 System.out.println("Please Try Again.....");
		           }
		          }
			      break;
		   case 4:System.out.println("Enter Account Number");
		          acNo=sc.next();
		          if(bservice.validateAccountNumber(acNo))
		          {
		           System.out.println("Enter Pin");
		           pin=sc.next();
		           if(bservice.validatePin(pin))
		           {
		            System.out.println("Enter Amount to withdraw");
		            long wamount=sc.nextLong();
			        try {
				     accountBalance=bservice.withdraw(acNo,pin,wamount);
				     if(accountBalance>=0)
		             {
		        	  System.out.println("Amount withdrawn Successfully");
          	          System.out.println("Account  Balance :"+accountBalance);
                     }
				     else
                     {
          	          System.out.println("Withdraw Failed");
          	          System.out.println("Please Try Again.....");
                     }
			        } catch (InsufficientBalanceException e) {
			         System.err.println("You have Insufficient Account Balance");	
			         e.printStackTrace();
				     
			        }
		           }
		          }
			      break;
		   case 5:System.out.println("Enter Source Account Number");
		          String sacNo=sc.next();
		          if(bservice.validateAccountNumber(sacNo))
		          {
		           System.out.println("Enter pin");
		           pin=sc.next();
		           if(bservice.validatePin(pin))
		           {
		            System.out.println("Enter Destination Account Number");
		            String dacNo=sc.next();
		            System.out.println("Enter amount to transfer");
		            long tamount=sc.nextLong();
			        boolean transfered;
			        try {
				     transfered = bservice.fundTransfer(sacNo, dacNo, tamount,pin);
				    if(transfered)
			         System.out.println("Amount Transfered Successfully");
			        else
			        {
			         System.out.println("Amount Transfered Failed");
			         System.out.println("Please Try Again.....");
			        }
			       } catch (InsufficientBalanceException e) {
					 System.err.println("You have Insufficient Account Balance");
					 e.printStackTrace();
			       }
		          }
			      }
			      break;
		   default:System.out.println("Please Enter a Valid Choice");
		  }
		  System.out.println("Do you want to continue : yes or no");
		  proceed=sc.next();
		}while(proceed.equalsIgnoreCase("yes"));
		sc.close();
	}
}
