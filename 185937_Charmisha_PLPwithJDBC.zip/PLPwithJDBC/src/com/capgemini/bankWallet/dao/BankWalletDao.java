package com.capgemini.bankWallet.dao;

import com.capgemini.bankWallet.exception.InsufficientBalanceException;
import com.capgemini.bankWallet.model.Account;

public interface BankWalletDao 
{
	  boolean saveAccount(Account a);
	  long viewBalance(String accountNo,String pin);
	  long depositCash(String accountNo,long amount);
	  long withdrawCash(String accountNo,String pin,long amount) throws InsufficientBalanceException;
	  boolean transferMoney(String sourceAcNo,String destAcNo,long amount,String pin) throws InsufficientBalanceException;
}
